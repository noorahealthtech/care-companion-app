//import liraries
import React, { Component } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Linking } from 'react-native';
import { Colors } from '../../../../../Theme';
import {
    Layout, Fonts, Images, WP
} from '@/Theme'
// create a component
// let url = props.course.training_url;
const CourseItem = (props) => {
    console.log('CourseProps=====',JSON.stringify(props))
    const openCoursesDetails = (links) => {
        try {
            Linking.openURL(links)
            console.log('Link is working===', links)
            return links.protocol === "http:" || links.protocol === "https:";
        } catch (error) {
           return  console.log('error==',error);
        }
       
    }


// const isValidHttpUrl = (string) => {
//      url;
    
//     try {
//       url = new URL(string);
//     } catch (_) {
//       return false;  
//     }
  
//     return url.protocol === "http:" || url.protocol === "https:";
//   }

    return (
        <TouchableOpacity style={styles.container}
            onPress={() => { openCoursesDetails(`${ "http://" + props.course.training_url}` ? `${ "http://" + props.course.training_url}` : `${ "https://" + props.course.training_url}`) }}
        >
            <View style={styles.header}>
                <Text allowFontScaling={false} style={styles.title}>{props.course.name}</Text>
                <Text allowFontScaling={false} style={styles.course}>{props.course.language.toUpperCase()}</Text>
            </View>
            <Image
                source={Images.forward}
                style={styles.drawer}
            />
        </TouchableOpacity>
    );
};

// define your styles
const styles = StyleSheet.create({
    container: {
        borderBottomWidth: 1,
        borderColor: Colors.coursesColor,
        width: WP('90'),
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between'
    },
    header: {
        display: 'flex'
    },
    drawer: {
        height: WP('15'),
        width: WP('5'),
        resizeMode: 'contain',
    },
    title: {
        color: Colors.grey,
        fontFamily: 'Assistant-Bold',
        fontSize: WP('5')
    },
    course: {
        color: Colors.coursesColor,
        fontFamily: 'Assistant-Bold',
        fontSize: WP('4'),
        marginTop: WP('1')
    }

});

//make this component available to the app
export default CourseItem;
