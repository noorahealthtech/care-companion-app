//Authentication
export const ADD_USER = 'ADD_USER';
export const LOG_OUT = 'LOG_OUT'

//Loader
export const SHOW_LOADER = 'SHOW_LOADER';
export const HIDE_LOADER = 'HIDE_LOADER';

//App story 
export const FEED_DATA = 'FEED_DATA';
export const NURSE_PROFILE = 'NURSE_PROFILE';
export const NURSE_PREVIOUS_CLASSES = 'NURSE_PREVIOUS_CLASSES'
export const NURSE_COMMENTS = 'NURSE_COMMENTS'
export const NURSE_LIKES = 'NURSE_LIKES'
export const ONLINE_COURSES = 'ONLINE_COURSES'
export const ADD_LIKE = 'ADD_LIKE'














