import 'react-native-gesture-handler'
import React from 'react'
import { Provider } from 'react-redux'
import { PersistGate } from 'redux-persist/lib/integration/react'
import { STORE, PERSISTOR } from './Store'
import { SafeAreaView, StatusBar } from 'react-native'
import { NavigationContainer } from '@react-navigation/native'
import { ApplicationNavigator } from '@/Navigators'
import { Layout } from '@/Theme'
import './Translations'
import { navigationRef } from './Services/navigation';
import { Colors } from './Theme'
import { LogBox } from 'react-native';
LogBox.ignoreLogs(['Warning: ...']); // Ignore log notification by message
LogBox.ignoreAllLogs();//Ignore all log notifications


const App = () => (
  <Provider store={STORE}>
    {/**
     * PersistGate delays the rendering of the app's UI until the persisted state has been retrieved
     * and saved to redux.
     * The `loading` prop can be `null` or any react instance to show during loading (e.g. a splash screen),
     * for example `loading={<SplashScreen />}`.
     * @see https://github.com/rt2zz/redux-persist/blob/master/docs/PersistGate.md
     */}
    <PersistGate loading={null} persistor={PERSISTOR}>
      <SafeAreaView style={Layout.fill}>
        <NavigationContainer ref={navigationRef}>
          <StatusBar barStyle={'dark-content'} backgroundColor={Colors.appColor} />
          <ApplicationNavigator />
        </NavigationContainer>
      </SafeAreaView>
    </PersistGate>
  </Provider>
)

export default App
