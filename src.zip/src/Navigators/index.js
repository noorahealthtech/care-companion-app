export { default as ApplicationNavigator } from './Application'
export { default as MainNavigator } from './Main'
